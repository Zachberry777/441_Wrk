This week was not to bad, The only thing i could not figure out was how to get my html to show up in firefox. But other then that i feel like i got the main concept.
I will most likely end up doing the extra credit for the next assignment just to get better points. I did start on my finals just with organization. I will be working on that alot this coming week though.
