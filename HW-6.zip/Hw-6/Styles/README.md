# 441_Wrk
Homework repo
So i finally am on time and even a day early! Feels good to be with the rest of the class now and i really enjoyed this project. I did find it hard and i had some help from the issue board. I finished the stuff that was asked like the name and age and with matching all the pictures. The pictures last about three seconds. I made mine with cats because my one year old baby Sage loves cats, so she was my insparation for this game. The only thing i didn't finish and didnt know how was to put the score in at the end, but other then that i was succesful with it. 
