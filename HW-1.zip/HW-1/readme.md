readme.md
I am zachary Hockenberry and i am now doing the first assignment at the end of the semester. Pretty sad, i know. I had a rough semester this year with some sad family times with me and my wife but things have gotten better since. I am majoring in Meadia arts and want to do something with graphic design or film editing. This is my fourth year in school, so that shows that i stick with it. I should be done by next summer if i take full classes this summer. My home town is whitehall MT which is 2 hours from here. I also like to weight lift and i really love my wife and my baby Sage. They mean everything to me and i really love rock music. I always wanted to be in the military from age 6-17 until i met my wife and wanted to do something less dangerous. I live for my wife and baby and will do anything to make them happy and to keep them safe.

https://github.com/Zachberry777/441_Wrk
https://github.com/Montana-Media-Arts/441-WebTech-Spring2019/issues
